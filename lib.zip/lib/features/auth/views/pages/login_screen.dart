import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:inventory_management/core/util/helpers/circle_indicator.dart';
import 'package:inventory_management/core/util/helpers/custom_button.dart';
import 'package:inventory_management/core/util/helpers/normal_text_field.dart';
import 'package:inventory_management/core/util/helpers/password_text_field.dart';
import 'package:inventory_management/core/util/screen_util_new.dart';
import 'package:inventory_management/features/auth/controller/login_controller.dart';
import 'package:inventory_management/features/auth/controller/sign_up_controller.dart';
import 'package:inventory_management/features/auth/views/pages/reset_password_screen.dart';
import 'package:inventory_management/features/auth/views/pages/sign_up_screen.dart';
import 'package:inventory_management/features/auth/services/user_service.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});
  final controller = Get.put(LoginController());
  final formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textTheme = theme.textTheme;

    return Scaffold(
      body: Obx(
        () => ModalProgressHUD(
          inAsyncCall: controller.isLoading.value,
          progressIndicator: const CircleIndicator(),
          child: SingleChildScrollView(
            child: Form(
              key: controller.formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(height: ScreenUtilNew.height(70)),
                  SizedBox(height: ScreenUtilNew.height(40)),
                  Center(
                    child: Text(
                      'Welcome Back',
                      style: textTheme.titleLarge?.copyWith(fontSize: 26.sp),
                    ),
                  ),
                  SizedBox(height: ScreenUtilNew.height(40)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: NormalTextField(
                      label: 'Email',
                      controller: controller.emailController,
                      hint: "mohamed@gmail.com",
                      validator: controller.validateEmail,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: PasswordTextField(
                      validator: controller.validatePassword,
                      label: 'Password',
                      controller: controller.passwordController,
                      isPasswordHidden: controller.isPasswordHidden,
                      togglePasswordVisibility:
                          controller.togglePasswordVisibility,
                      hint: '**********',
                    ),
                  ),
                  SizedBox(height: ScreenUtilNew.height(24)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8.w),
                    child: Row(
                      children: [
                        Row(
                          children: [
                            Obx(
                              () => Checkbox(
                                fillColor: WidgetStateProperty.all(Colors.red),
                                checkColor: Colors.white,
                                value: controller.rememberMe.value,
                                onChanged: (value) {
                                  controller.rememberMe.value = value!;
                                },
                              ),
                            ),
                            Text(
                              'Remember Me',
                              style: textTheme.bodyLarge,
                            ),
                          ],
                        ),
                        const Spacer(flex: 2),
                        TextButton(
                          onPressed: () {
                            Get.to(() => ResetPasswordScreen(),
                                transition: Transition.rightToLeft);
                          },
                          child: Text(
                            'Forget Password?',
                            style: textTheme.bodyLarge?.copyWith(
                                decoration: TextDecoration.underline),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: ScreenUtilNew.height(24)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.w),
                    child: CustomButton(
                      text: 'Login',
                      onPressed: () {
                        if (controller.formKey.currentState!.validate()) {
                          controller.signIn();
                        }
                      },
                    ),
                  ),
                  SizedBox(height: ScreenUtilNew.height(24)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Don\'t have an account?',
                        style: textTheme.bodyLarge,
                      ),
                      TextButton(
                        onPressed: () {
                          Get.offAll(() => SignUpScreen());
                        },
                        child: Text(
                          'Sign Up',
                          style: textTheme.bodyLarge
                              ?.copyWith(decoration: TextDecoration.underline),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: ScreenUtilNew.height(70)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
